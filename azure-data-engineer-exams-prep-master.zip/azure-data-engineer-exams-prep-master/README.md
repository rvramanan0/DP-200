# azure-data-engineer-exams-prep
Preparation resources for exams DP-200 and DP-201
