Different dump solution images
