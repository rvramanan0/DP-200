# Study guide and useful tips gathered

1. [Microsoft-Official-doc](https://docs.microsoft.com/en-us/learn/browse/?products=azure&resource_type=learning%20path&roles=data-engineer)

2. [Cathrine-Study-Guide](https://www.cathrinewilhelmsen.net/2019/05/29/preparing-taking-microsoft-exam-dp-200-implementing-azure-data-solution/)

3. [Mario-Study-Guide](https://medium.com/@marioamendieta/dp-200-implementing-an-azure-data-solution-beta-study-guide-192c3892e042)

4. [Shivam-Study-Guide](https://medium.com/deep-ai/self-study-guide-microsoft-azure-certification-dp-200-implementing-an-azure-data-solution-a55616225ae3)

##### Yet-to-update

5. [Mehdi-Study-Guide](http://www.mycloudypuzzle.com/2019/02/15/azure-exam-dp-200-implementing-an-azure-data-solution/)
 
## Videos

1. [Question-Types](https://youtu.be/7CvYGpSVbkA?list=PLahhVEj9XNTdZrAYjA7mq4bH1X5cTykpH)

2. [SQL-Bits](https://sqlbits.com/)

3. [Microsoft-Ignite](https://www.youtube.com/watch?v=FpSMVdaP8Tk&list=PLQXpv_NQsPICar3RMOsnUsIWy7OfYGg-X)

## Azure Lab Preparation

1. [Lab-Questions](https://github.com/MicrosoftLearning/DP-200-Implementing-an-Azure-Data-Solution)
